﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace С_думи
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(textBox1.Text, out int value))
            {
                withWords.Text = "Това не е число!";
            }
            else
            {
                int num = int.Parse(textBox1.Text);
                string word;
                switch (num)
                {
                    case 1: word = "едно"; break;
                    case 2: word = "две"; break;
                    case 3: word = "три"; break;
                    case 4: word = "четири"; break;
                    case 5: word = "пет"; break;
                    case 6: word = "шест"; break;
                    case 7: word = "седем"; break;
                    case 8: word = "осем"; break;
                    case 9: word = "девет"; break;
                    case 10: word = "десет"; break;
                    case 11: word = "единадесет"; break;
                    case 12: word = "дванадесет"; break;
                    case 13: word = "тринадесет"; break;
                    case 14: word = "четиринадесет"; break;
                    case 15: word = "петнадесет"; break;
                    case 16: word = "шестнадесет"; break;
                    case 17: word = "седемнадесет"; break;
                    case 18: word = "осемнадесет"; break;
                    case 19: word = "деветнадесет"; break;
                    case 20: word = "двадесет"; break;
                    default: word = "число извън диапазона [1...20]"; break;
                }
                withWords.Text = word;
            }
            textBox1.Text = string.Empty;
        }
    }
}
